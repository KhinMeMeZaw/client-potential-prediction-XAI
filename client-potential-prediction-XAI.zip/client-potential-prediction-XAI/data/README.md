## Data Folder

Contains raw and processed data files.

⚠️ Note: The actual dataset is private due to confidentiality. Only sample structure files or descriptions should be included here.