## Models Folder

Holds saved trained models (e.g., `.pkl` files) from Gradient Boosting, LightGBM, Random Forest, etc.