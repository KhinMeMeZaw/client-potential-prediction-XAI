## Notebooks Folder

Contains Jupyter notebooks demonstrating each step of the analysis and modeling process.