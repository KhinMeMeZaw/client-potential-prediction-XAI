## Presentation Folder

Includes presentation slides or summary reports used for research or project defense.